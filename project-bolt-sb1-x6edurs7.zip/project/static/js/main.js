document.addEventListener('DOMContentLoaded', function() {
    const messageInput = document.getElementById('messageInput');
    const checkButton = document.getElementById('checkButton');
    const demoInput = document.getElementById('demoInput');
    const sendButton = document.getElementById('sendButton');
    const chatMessages = document.getElementById('chatMessages');
    const exampleButtons = document.querySelectorAll('.example-btn');

    async function classifyMessage(message) {
        try {
            const response = await fetch('/classify', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ message })
            });
            return await response.json();
        } catch (error) {
            console.error('Error:', error);
            return null;
        }
    }

    function addMessage(message, isUser = false) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isUser ? 'user' : 'bot'}`;
        messageDiv.textContent = message;
        chatMessages.appendChild(messageDiv);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    async function handleMessageSubmit(message) {
        if (!message.trim()) return;

        addMessage(message, true);
        const result = await classifyMessage(message);

        if (result) {
            let response = result.isSpam
                ? `🚨 Likely spam (${result.confidence.toFixed(0)}% confidence).`
                : `✅ Genuine message (${result.confidence.toFixed(0)}% confidence).`;

            if (result.keywords && result.keywords.length > 0) {
                response += '\n\nFlagged keywords: ' + result.keywords.join(', ');
            }

            addMessage(response);
        }
    }

    checkButton.addEventListener('click', () => {
        handleMessageSubmit(messageInput.value);
        messageInput.value = '';
    });

    sendButton.addEventListener('click', () => {
        handleMessageSubmit(demoInput.value);
        demoInput.value = '';
    });

    demoInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleMessageSubmit(demoInput.value);
            demoInput.value = '';
        }
    });

    exampleButtons.forEach(button => {
        button.addEventListener('click', () => {
            demoInput.value = button.textContent;
            handleMessageSubmit(button.textContent);
            demoInput.value = '';
        });
    });
});