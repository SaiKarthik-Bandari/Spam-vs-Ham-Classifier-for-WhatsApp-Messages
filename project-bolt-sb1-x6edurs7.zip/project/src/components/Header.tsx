import React, { useState, useEffect } from 'react';
import { ShieldCheck, Menu, X } from 'lucide-react';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
      }`}
    >
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div className="flex items-center">
          <ShieldCheck className="text-ham mr-2" size={28} />
          <span className="font-bold text-xl font-poppins">SpamGuard</span>
        </div>
        
        {/* Desktop Navigation */}
        <nav className="hidden md:block">
          <ul className="flex space-x-8">
            <li><a href="#home" className="font-semibold hover:text-ham transition-colors">Home</a></li>
            <li><a href="#demo" className="font-semibold hover:text-ham transition-colors">Demo</a></li>
            <li><a href="#how-it-works" className="font-semibold hover:text-ham transition-colors">How It Works</a></li>
            <li><a href="#trust" className="font-semibold hover:text-ham transition-colors">Trust</a></li>
          </ul>
        </nav>
        
        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-gray-700 focus:outline-none"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>
      
      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-white shadow-lg absolute w-full">
          <nav className="container mx-auto px-4 py-4">
            <ul className="space-y-4">
              <li>
                <a 
                  href="#home" 
                  className="block font-semibold py-2 hover:text-ham transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Home
                </a>
              </li>
              <li>
                <a 
                  href="#demo" 
                  className="block font-semibold py-2 hover:text-ham transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Demo
                </a>
              </li>
              <li>
                <a 
                  href="#how-it-works" 
                  className="block font-semibold py-2 hover:text-ham transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  How It Works
                </a>
              </li>
              <li>
                <a 
                  href="#trust" 
                  className="block font-semibold py-2 hover:text-ham transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Trust
                </a>
              </li>
            </ul>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;