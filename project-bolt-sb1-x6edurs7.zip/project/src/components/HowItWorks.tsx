import React from 'react';
import { Database, Brain, Zap } from 'lucide-react';

const HowItWorks: React.FC = () => {
  return (
    <section id="how-it-works" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-2 text-center">How It Works</h2>
        <p className="text-xl text-gray-600 text-center mb-16">The science behind spam detection, explained simply.</p>
        
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col md:flex-row relative">
            {/* Timeline line */}
            <div className="hidden md:block w-1 bg-gray-200 absolute h-full left-1/2 transform -translate-x-1/2"></div>
            
            {/* Step 1 */}
            <div className="mb-16 md:mb-0 md:w-1/2 md:pr-12 md:text-right section-transition hover-scale">
              <div className="flex md:justify-end">
                <div className="bg-blue-500 text-white rounded-full w-12 h-12 flex items-center justify-center mb-4 md:mb-0 md:ml-4 z-10">
                  <Database size={24} />
                </div>
              </div>
              <div>
                <h3 className="text-2xl font-bold mb-3">We Analyzed Thousands of Messages</h3>
                <p className="text-gray-600 mb-4">Our system was trained on a massive dataset of real messages, carefully labeled as spam or legitimate (ham).</p>
                <div className="bg-gray-50 p-4 rounded-lg shadow-sm">
                  <div className="flex items-center justify-center gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">87%</div>
                      <div className="text-sm text-gray-500">Ham</div>
                    </div>
                    <div className="h-10 w-px bg-gray-300"></div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-red-500">13%</div>
                      <div className="text-sm text-gray-500">Spam</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="md:w-1/2"></div>
            
            {/* Step 2 */}
            <div className="mb-16 md:mb-0 md:w-1/2 md:pl-12 section-transition hover-scale">
              <div className="flex md:justify-start">
                <div className="bg-purple-500 text-white rounded-full w-12 h-12 flex items-center justify-center mb-4 md:mb-0 md:mr-4 z-10">
                  <Brain size={24} />
                </div>
              </div>
              <div>
                <h3 className="text-2xl font-bold mb-3">The System Learns Patterns</h3>
                <p className="text-gray-600 mb-4">Using sophisticated algorithms, our classifier identifies patterns and features that distinguish spam from legitimate messages.</p>
                <div className="bg-gray-50 p-4 rounded-lg shadow-sm">
                  <div className="flex flex-col space-y-2">
                    <div className="flex items-center">
                      <div className="w-1/3 text-right pr-2 text-sm text-gray-600">Message</div>
                      <div className="w-1/3 text-center">→</div>
                      <div className="w-1/3 pl-2 text-sm text-gray-600">Words, Phrases</div>
                    </div>
                    <div className="flex items-center">
                      <div className="w-1/3 text-right pr-2 text-sm text-gray-600">Words, Phrases</div>
                      <div className="w-1/3 text-center">→</div>
                      <div className="w-1/3 pl-2 text-sm text-gray-600">Pattern Recognition</div>
                    </div>
                    <div className="flex items-center">
                      <div className="w-1/3 text-right pr-2 text-sm text-gray-600">Pattern Recognition</div>
                      <div className="w-1/3 text-center">→</div>
                      <div className="w-1/3 pl-2 text-sm text-gray-600">Spam Probability</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="md:w-1/2"></div>
            
            {/* Step 3 */}
            <div className="md:w-1/2 md:pr-12 md:text-right section-transition hover-scale">
              <div className="flex md:justify-end">
                <div className="bg-yellow-500 text-white rounded-full w-12 h-12 flex items-center justify-center mb-4 md:mb-0 md:ml-4 z-10">
                  <Zap size={24} />
                </div>
              </div>
              <div>
                <h3 className="text-2xl font-bold mb-3">You Get Instant Results</h3>
                <p className="text-gray-600 mb-4">In milliseconds, our classifier analyzes your message and delivers a verdict, helping you avoid scams and phishing attempts.</p>
                <div className="relative bg-gray-50 p-4 rounded-lg shadow-sm overflow-hidden">
                  <div className="flex flex-col items-center">
                    <div className="w-64 h-12 bg-white rounded-lg border border-gray-200 flex items-center justify-between px-3 mb-3">
                      <span className="text-sm text-gray-500 truncate">Your message here...</span>
                      <button className="bg-green-500 text-white text-xs py-1 px-2 rounded">Check</button>
                    </div>
                    <div className="w-64 h-10 bg-green-100 border border-green-500 rounded-lg flex items-center justify-center text-green-700 text-sm">
                      ✅ Genuine message (95% confidence)
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;