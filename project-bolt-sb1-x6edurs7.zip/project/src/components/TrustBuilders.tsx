import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Star } from 'lucide-react';

interface Testimonial {
  id: number;
  name: string;
  role: string;
  quote: string;
  rating: number;
}

const testimonials: Testimonial[] = [
  {
    id: 1,
    name: "Sarah T.",
    role: "Marketing Manager",
    quote: "This saved me from phishing scams! I almost fell for a fake delivery notification until SpamGuard flagged it.",
    rating: 5
  },
  {
    id: 2,
    name: "Prof. James L.",
    role: "Computer Science Professor",
    quote: "I teach this in my class—a brilliant example of machine learning that's simple yet powerful.",
    rating: 5
  },
  {
    id: 3,
    name: "Miguel R.",
    role: "Small Business Owner",
    quote: "Our team receives hundreds of messages daily. This tool helps us focus on what matters.",
    rating: 4
  }
];

const TrustBuilders: React.FC = () => {
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [sliderPosition, setSliderPosition] = useState(50);
  
  const nextTestimonial = () => {
    setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
  };
  
  const prevTestimonial = () => {
    setCurrentTestimonial((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };
  
  return (
    <section id="trust" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-2 text-center">See It in Action</h2>
        <p className="text-xl text-gray-600 text-center mb-16">Real-world examples of SpamGuard making a difference.</p>
        
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col lg:flex-row gap-12 items-center">
            {/* Video/Animation Section */}
            <div className="lg:w-1/2">
              <div className="relative overflow-hidden rounded-xl shadow-xl">
                <div className="aspect-w-16 aspect-h-9 bg-gray-800 text-white flex items-center justify-center relative">
                  {/* This would be a video in a real implementation */}
                  <div className="absolute inset-0 flex">
                    {/* Spam side */}
                    <div 
                      className="bg-red-100 p-6"
                      style={{ width: `${sliderPosition}%` }}
                    >
                      <div className="h-full flex flex-col">
                        <div className="text-center mb-4">
                          <h3 className="text-xl font-bold text-red-600">Cluttered Inbox</h3>
                        </div>
                        <div className="flex-1 overflow-y-auto space-y-2">
                          <div className="bg-white rounded p-3 shadow-sm border-l-4 border-red-500">
                            <p className="text-sm text-gray-800">URGENT: Your account needs verification!</p>
                          </div>
                          <div className="bg-white rounded p-3 shadow-sm">
                            <p className="text-sm text-gray-800">Meeting at 2 PM tomorrow</p>
                          </div>
                          <div className="bg-white rounded p-3 shadow-sm border-l-4 border-red-500">
                            <p className="text-sm text-gray-800">You've won a new iPhone! Claim now!</p>
                          </div>
                          <div className="bg-white rounded p-3 shadow-sm">
                            <p className="text-sm text-gray-800">Can you review this document?</p>
                          </div>
                          <div className="bg-white rounded p-3 shadow-sm border-l-4 border-red-500">
                            <p className="text-sm text-gray-800">Your payment failed - update details now</p>
                          </div>
                          <div className="bg-white rounded p-3 shadow-sm">
                            <p className="text-sm text-gray-800">Dinner on Friday?</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    {/* Clean side */}
                    <div 
                      className="bg-green-100 p-6"
                      style={{ width: `${100 - sliderPosition}%` }}
                    >
                      <div className="h-full flex flex-col">
                        <div className="text-center mb-4">
                          <h3 className="text-xl font-bold text-green-600">Clean Inbox</h3>
                        </div>
                        <div className="flex-1 overflow-y-auto space-y-2">
                          <div className="bg-white rounded p-3 shadow-sm">
                            <p className="text-sm text-gray-800">Meeting at 2 PM tomorrow</p>
                          </div>
                          <div className="bg-white rounded p-3 shadow-sm">
                            <p className="text-sm text-gray-800">Can you review this document?</p>
                          </div>
                          <div className="bg-white rounded p-3 shadow-sm">
                            <p className="text-sm text-gray-800">Dinner on Friday?</p>
                          </div>
                        </div>
                        <div className="mt-4 bg-gray-200 rounded-lg p-3">
                          <h4 className="text-sm font-semibold text-gray-700">Spam Folder (3)</h4>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Slider control */}
                  <div className="absolute inset-0 flex items-center pointer-events-none">
                    <div 
                      className="h-full w-0.5 bg-gray-600 opacity-70"
                      style={{ left: `${sliderPosition}%`, position: 'absolute' }}
                    ></div>
                    <div 
                      className="h-8 w-8 rounded-full bg-white shadow-lg flex items-center justify-center border border-gray-400 cursor-pointer pointer-events-auto"
                      style={{ left: `${sliderPosition}%`, position: 'absolute', transform: 'translateX(-50%)' }}
                      onMouseDown={() => {
                        const handleMouseMove = (e: MouseEvent) => {
                          const container = e.currentTarget as Window;
                          const rect = document.getElementById('trust')?.getBoundingClientRect();
                          if (rect) {
                            const containerWidth = rect.width;
                            const offsetX = e.clientX - rect.left;
                            const newPosition = Math.max(10, Math.min(90, (offsetX / containerWidth) * 100));
                            setSliderPosition(newPosition);
                          }
                        };
                        
                        const handleMouseUp = () => {
                          window.removeEventListener('mousemove', handleMouseMove);
                          window.removeEventListener('mouseup', handleMouseUp);
                        };
                        
                        window.addEventListener('mousemove', handleMouseMove);
                        window.addEventListener('mouseup', handleMouseUp);
                      }}
                    >
                      <span className="transform -rotate-90">⟷</span>
                    </div>
                  </div>
                  
                  <div className="absolute bottom-4 left-0 right-0 text-center text-white text-sm">
                    <span className="bg-black bg-opacity-50 px-3 py-1 rounded-full">
                      Drag to compare
                    </span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Testimonials section */}
            <div className="lg:w-1/2">
              <div className="bg-white rounded-xl shadow-lg p-8 relative">
                <div className="absolute -top-4 -left-4 text-6xl text-gray-200">"</div>
                
                <div className="min-h-[200px]">
                  <div className="mb-6">
                    <div className="flex mb-1">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i}
                          size={20}
                          className={i < testimonials[currentTestimonial].rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}
                        />
                      ))}
                    </div>
                    <p className="text-lg italic mb-6">
                      {testimonials[currentTestimonial].quote}
                    </p>
                    <div>
                      <p className="font-semibold">{testimonials[currentTestimonial].name}</p>
                      <p className="text-gray-500 text-sm">{testimonials[currentTestimonial].role}</p>
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-between mt-8">
                  <button 
                    onClick={prevTestimonial}
                    className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
                    aria-label="Previous testimonial"
                  >
                    <ChevronLeft size={20} />
                  </button>
                  
                  <div className="flex space-x-2">
                    {testimonials.map((_, i) => (
                      <button
                        key={i}
                        onClick={() => setCurrentTestimonial(i)}
                        className={`w-3 h-3 rounded-full ${i === currentTestimonial ? 'bg-green-500' : 'bg-gray-300'}`}
                        aria-label={`Go to testimonial ${i + 1}`}
                      />
                    ))}
                  </div>
                  
                  <button 
                    onClick={nextTestimonial}
                    className="p-2 rounded-full bg-gray-100 hover:bg-gray-200 transition-colors"
                    aria-label="Next testimonial"
                  >
                    <ChevronRight size={20} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TrustBuilders;