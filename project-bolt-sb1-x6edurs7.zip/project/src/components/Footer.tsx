import React from 'react';
import { ShieldCheck, Mail, Download, ChevronRight } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10">
          <div className="mb-8 md:mb-0">
            <div className="flex items-center">
              <ShieldCheck className="text-green-400 mr-2" size={28} />
              <span className="font-bold text-xl">SpamGuard</span>
            </div>
            <p className="text-gray-400 mt-2 max-w-sm">
              Protecting your WhatsApp conversations from unwanted spam messages.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-6 sm:gap-12">
            <div>
              <h3 className="font-semibold text-lg mb-4">Quick Links</h3>
              <ul className="space-y-2">
                <li>
                  <a href="#home" className="text-gray-400 hover:text-white transition-colors flex items-center">
                    <ChevronRight size={16} className="mr-1" />
                    Home
                  </a>
                </li>
                <li>
                  <a href="#demo" className="text-gray-400 hover:text-white transition-colors flex items-center">
                    <ChevronRight size={16} className="mr-1" />
                    Try the Demo
                  </a>
                </li>
                <li>
                  <a href="#how-it-works" className="text-gray-400 hover:text-white transition-colors flex items-center">
                    <ChevronRight size={16} className="mr-1" />
                    How It Works
                  </a>
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold text-lg mb-4">Resources</h3>
              <ul className="space-y-2">
                <li>
                  <a href="#" className="text-gray-400 hover:text-white transition-colors flex items-center group">
                    <Download size={16} className="mr-1 group-hover:text-green-400" />
                    <span>Spam Keyword Cheatsheet</span>
                  </a>
                </li>
                <li>
                  <a href="#" className="text-gray-400 hover:text-white transition-colors flex items-center group">
                    <Mail size={16} className="mr-1 group-hover:text-green-400" />
                    <span>Contact Us</span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="pt-8 border-t border-gray-800 text-center">
          <div className="flex flex-col md:flex-row justify-center items-center gap-4 mb-6">
            <a 
              href="#demo" 
              className="bg-green-600 hover:bg-green-700 transition-colors text-white font-bold py-3 px-6 rounded-lg"
            >
              Try the Spam Checker Now
            </a>
            <a 
              href="#" 
              className="bg-gray-700 hover:bg-gray-600 transition-colors text-white font-bold py-3 px-6 rounded-lg"
            >
              How to Spot Spam Yourself
            </a>
          </div>
          
          <p className="text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} SpamGuard. All rights reserved. This is a demonstration project.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;