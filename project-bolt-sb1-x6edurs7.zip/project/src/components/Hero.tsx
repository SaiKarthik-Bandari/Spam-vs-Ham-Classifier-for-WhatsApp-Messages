import React, { useState, useEffect, useRef } from 'react';
import { ChevronRight, AlertTriangle, CheckCircle } from 'lucide-react';
import { useMessageClassifier } from '../context/MessageClassifierContext';

const Hero: React.FC = () => {
  const [message, setMessage] = useState('');
  const [showSlider, setShowSlider] = useState(true);
  const [sliderPosition, setSliderPosition] = useState(50);
  const { addMessage } = useMessageClassifier();
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      if (showSlider) {
        setSliderPosition(prev => {
          if (prev >= 85) return 15;
          return prev + 5;
        });
      }
    }, 2000);
    
    return () => clearInterval(interval);
  }, [showSlider]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      addMessage(message);
      // Scroll to demo section
      const demoSection = document.getElementById('demo');
      if (demoSection) {
        demoSection.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      // Focus on the input if empty
      if (inputRef.current) {
        inputRef.current.focus();
      }
    }
  };

  return (
    <section id="home" className="min-h-screen pt-20 relative overflow-hidden">
      <div className="container mx-auto px-4 py-16 flex flex-col lg:flex-row items-center">
        <div className="lg:w-1/2 z-10">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 leading-tight">
            Is Your WhatsApp Message <span className="text-spam">Spam</span> or <span className="text-ham">Ham</span>?
          </h1>
          <p className="text-xl mb-8 text-gray-700">
            A smart filter trained to spot spam—no downloads, no hassle.
          </p>
          
          <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-lg mb-8">
            <textarea
              ref={inputRef}
              className="w-full p-4 border border-gray-300 rounded-lg focus:border-ham focus:ring-1 focus:ring-ham focus:outline-none transition-all mb-4 h-32"
              placeholder="Paste a suspicious message here..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
            />
            <button 
              type="submit"
              className="bg-ham hover:bg-green-600 text-white font-bold py-3 px-6 rounded-lg transition-colors flex items-center"
            >
              Check Now <ChevronRight className="ml-2" size={20} />
            </button>
          </form>
        </div>
        
        <div className="lg:w-1/2 relative h-96 lg:h-auto">
          <div className="absolute inset-0 flex">
            {/* Before side - with Spam */}
            <div 
              className="w-1/2 bg-red-50 flex items-center justify-center overflow-hidden"
              style={{ width: `${sliderPosition}%` }}
            >
              <div className="p-6 flex flex-col space-y-4 w-full max-w-xs transform scale-75 md:scale-90 lg:scale-100">
                <div className="bg-white p-4 rounded-lg shadow relative">
                  <p className="font-medium">Congrats! You won a $1000 voucher!</p>
                  <div className="absolute -top-2 -right-2 bg-spam text-white rounded-full p-1">
                    <AlertTriangle size={16} />
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg shadow relative">
                  <p className="font-medium">Your parcel needs urgent collection. Click here:</p>
                  <div className="absolute -top-2 -right-2 bg-spam text-white rounded-full p-1">
                    <AlertTriangle size={16} />
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg shadow relative">
                  <p className="font-medium">Limited time: 90% discount on all Apple products!</p>
                  <div className="absolute -top-2 -right-2 bg-spam text-white rounded-full p-1">
                    <AlertTriangle size={16} />
                  </div>
                </div>
              </div>
            </div>
            
            {/* After side - without Spam */}
            <div 
              className="flex-grow bg-green-50 flex items-center justify-center overflow-hidden"
              style={{ width: `${100 - sliderPosition}%` }}
            >
              <div className="p-6 flex flex-col space-y-4 w-full max-w-xs transform scale-75 md:scale-90 lg:scale-100">
                <div className="bg-white p-4 rounded-lg shadow relative">
                  <p className="font-medium">Hey, are we still meeting tomorrow?</p>
                  <div className="absolute -top-2 -right-2 bg-ham text-white rounded-full p-1">
                    <CheckCircle size={16} />
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg shadow relative">
                  <p className="font-medium">Can you pick up some milk on your way home?</p>
                  <div className="absolute -top-2 -right-2 bg-ham text-white rounded-full p-1">
                    <CheckCircle size={16} />
                  </div>
                </div>
                <div className="bg-white p-4 rounded-lg shadow relative">
                  <p className="font-medium">The meeting is postponed to 3pm today.</p>
                  <div className="absolute -top-2 -right-2 bg-ham text-white rounded-full p-1">
                    <CheckCircle size={16} />
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Slider Control */}
          <div className="absolute inset-0 flex items-center pointer-events-none z-10">
            <div 
              className="h-full w-2 bg-gray-800 opacity-50"
              style={{ left: `${sliderPosition}%`, position: 'absolute' }}
            ></div>
            <div 
              className="h-10 w-10 rounded-full bg-white shadow-lg flex items-center justify-center border-2 border-gray-800"
              style={{ left: `${sliderPosition}%`, position: 'absolute', transform: 'translateX(-50%)' }}
            >
              <span className="transform -rotate-90">⟷</span>
            </div>
          </div>
          
          {/* Labels */}
          <div className="absolute top-4 left-4 bg-spam text-white px-3 py-1 rounded-full text-sm font-bold">
            With Spam
          </div>
          <div className="absolute top-4 right-4 bg-ham text-white px-3 py-1 rounded-full text-sm font-bold">
            Spam-Free
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-10 left-0 right-0 flex justify-center">
        <a 
          href="#demo"
          className="text-gray-700 flex flex-col items-center hover:text-ham transition-colors"
        >
          <span className="mb-2">Try it out</span>
          <ChevronRight className="transform rotate-90" size={24} />
        </a>
      </div>
    </section>
  );
};

export default Hero;