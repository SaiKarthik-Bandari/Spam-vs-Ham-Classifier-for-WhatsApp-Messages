import React, { useState, useRef, useEffect } from 'react';
import { Send, Info } from 'lucide-react';
import { useMessageClassifier } from '../context/MessageClassifierContext';

const EXAMPLE_MESSAGES = [
  "Congrats! You won a $1000 voucher!",
  "Limited time offer! 90% off all products!",
  "Your PayPal account has been limited. Click here to verify your identity.",
  "Hey, are we still meeting tomorrow?",
  "Can you pick up some milk on your way home?"
];

interface Confetti {
  id: number;
  x: number;
  y: number;
  color: string;
}

const Demo: React.FC = () => {
  const [message, setMessage] = useState('');
  const [chatHistory, setChatHistory] = useState<Array<{
    sender: 'user' | 'bot';
    text: string;
    isSpam?: boolean;
    confidence?: number;
    keywords?: string[];
  }>>([
    { sender: 'bot', text: 'Hi there! Send me a message to check if it\'s spam or not.' }
  ]);
  const [showKeywords, setShowKeywords] = useState<{[key: number]: boolean}>({});
  const [confetti, setConfetti] = useState<Confetti[]>([]);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const { classifyMessage } = useMessageClassifier();
  
  const scrollToBottom = () => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  };
  
  useEffect(() => {
    scrollToBottom();
  }, [chatHistory]);
  
  const createConfetti = () => {
    const colors = ['#F44336', '#4CAF50', '#2196F3', '#FFEB3B', '#9C27B0', '#FF9800'];
    const newConfetti = Array.from({ length: 50 }).map((_, index) => ({
      id: Date.now() + index,
      x: Math.random() * 100,
      y: -10 - Math.random() * 40,
      color: colors[Math.floor(Math.random() * colors.length)]
    }));
    
    setConfetti(prev => [...prev, ...newConfetti]);
    setTimeout(() => {
      setConfetti(prev => prev.filter(c => !newConfetti.includes(c)));
    }, 3000);
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    
    // Add user message
    setChatHistory(prev => [...prev, { sender: 'user', text: message }]);
    
    // Analyze the message
    const result = classifyMessage(message);
    
    // Prepare the bot response
    let botResponse = '';
    if (result.isSpam) {
      botResponse = `🚨 Likely spam (${result.confidence.toFixed(0)}% confidence).`;
    } else {
      botResponse = `✅ Genuine message (${result.confidence.toFixed(0)}% confidence).`;
      createConfetti();
    }
    
    // Add bot response with a slight delay for a more natural conversation flow
    setTimeout(() => {
      setChatHistory(prev => [
        ...prev, 
        { 
          sender: 'bot', 
          text: botResponse, 
          isSpam: result.isSpam,
          confidence: result.confidence,
          keywords: result.keywords
        }
      ]);
    }, 800);
    
    setMessage('');
  };
  
  const handleExampleClick = (exampleText: string) => {
    setMessage(exampleText);
  };
  
  const toggleKeywords = (index: number) => {
    setShowKeywords(prev => ({
      ...prev,
      [index]: !prev[index]
    }));
  };
  
  return (
    <section id="demo" className="py-20 bg-gray-100">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold mb-2 text-center">Try It Yourself</h2>
        <p className="text-xl text-gray-600 text-center mb-12">Send a message and see if it's spam or not.</p>
        
        <div className="max-w-md mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
          {/* WhatsApp-like header */}
          <div className="bg-green-600 text-white p-3 flex items-center">
            <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-shield-check text-green-600"><path d="M20 13c0 5-3.5 7.5-8 8.5-4.5-1-8-3.5-8-8.5V6.75c0-1.12.9-2.03 2.02-2.03 2.03 0 5.98-1.22 5.98-1.22.67-.19 1.39-.19 2.06 0 0 0 3.95 1.22 5.98 1.22C21.1 4.72 22 5.63 22 6.75V13"/><path d="m9 12 2 2 4-4"/></svg>
            </div>
            <div className="ml-3">
              <div className="font-bold">SpamGuard</div>
              <div className="text-xs opacity-90">Your personal message classifier</div>
            </div>
          </div>
          
          {/* Chat area */}
          <div className="h-96 px-4 py-2 overflow-y-auto whatsapp-bg">
            {chatHistory.map((chat, index) => (
              <div key={index} className="mb-4">
                <div className={`chat-bubble ${chat.sender === 'user' ? 'user-message' : 'bot-message'}`}>
                  <p>{chat.text}</p>
                  
                  {chat.keywords && chat.keywords.length > 0 && (
                    <div>
                      <button 
                        onClick={() => toggleKeywords(index)}
                        className="text-xs flex items-center mt-1 text-gray-600 hover:text-gray-900"
                      >
                        <Info size={14} className="mr-1" />
                        {showKeywords[index] ? 'Hide why' : 'Why?'}
                      </button>
                      
                      {showKeywords[index] && (
                        <div className="mt-2 p-2 bg-gray-100 rounded text-sm">
                          <p className="font-semibold">Flagged keywords:</p>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {chat.keywords.map((keyword, i) => (
                              <span key={i} className="bg-gray-200 px-2 py-1 rounded text-xs">
                                {keyword}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
            <div ref={chatEndRef} />
          </div>
          
          {/* Message input */}
          <form onSubmit={handleSubmit} className="p-3 border-t border-gray-200 flex items-center">
            <input
              type="text"
              className="flex-1 py-2 px-3 rounded-full bg-gray-100 focus:outline-none focus:ring-1 focus:ring-green-500"
              placeholder="Type a message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
            />
            <button
              type="submit"
              className="ml-2 p-2 bg-green-600 text-white rounded-full focus:outline-none hover:bg-green-700 transition-colors"
            >
              <Send size={20} />
            </button>
          </form>
        </div>
        
        {/* Example messages */}
        <div className="mt-8 text-center">
          <p className="text-gray-600 mb-3">Try these examples:</p>
          <div className="flex flex-wrap justify-center gap-2">
            {EXAMPLE_MESSAGES.map((exampleText, index) => (
              <button
                key={index}
                className="bg-white hover:bg-gray-50 py-2 px-4 rounded border shadow-sm text-sm transition-colors"
                onClick={() => handleExampleClick(exampleText)}
              >
                {exampleText.length > 30 ? exampleText.substring(0, 27) + '...' : exampleText}
              </button>
            ))}
          </div>
        </div>
        
        {/* Confetti animation */}
        {confetti.map(c => (
          <div
            key={c.id}
            className="confetti"
            style={{
              left: `${c.x}vw`,
              top: `${c.y}vh`,
              backgroundColor: c.color
            }}
          />
        ))}
      </div>
    </section>
  );
};

export default Demo;