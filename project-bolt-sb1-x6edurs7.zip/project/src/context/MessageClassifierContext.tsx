import React, { createContext, useContext, useState, ReactNode } from 'react';
import { classifyMessage } from '../utils/classifier';

interface ClassificationResult {
  isSpam: boolean;
  confidence: number;
  keywords?: string[];
}

interface MessageClassifierContextType {
  classifyMessage: (message: string) => ClassificationResult;
  recentMessages: { message: string; result: ClassificationResult }[];
  addMessage: (message: string) => void;
  clearMessages: () => void;
}

const MessageClassifierContext = createContext<MessageClassifierContextType | undefined>(undefined);

export const useMessageClassifier = () => {
  const context = useContext(MessageClassifierContext);
  if (!context) {
    throw new Error('useMessageClassifier must be used within a MessageClassifierProvider');
  }
  return context;
};

export const MessageClassifierProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [recentMessages, setRecentMessages] = useState<
    { message: string; result: ClassificationResult }[]
  >([]);

  const addMessage = (message: string) => {
    const result = classifyMessage(message);
    setRecentMessages((prev) => [{ message, result }, ...prev].slice(0, 5));
    return result;
  };

  const clearMessages = () => {
    setRecentMessages([]);
  };

  return (
    <MessageClassifierContext.Provider
      value={{
        classifyMessage,
        recentMessages,
        addMessage,
        clearMessages,
      }}
    >
      {children}
    </MessageClassifierContext.Provider>
  );
};