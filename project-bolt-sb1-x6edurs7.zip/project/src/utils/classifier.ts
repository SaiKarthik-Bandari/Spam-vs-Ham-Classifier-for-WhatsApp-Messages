import * as tf from '@tensorflow/tfjs';

// Sample spam keywords and patterns (same as before)
const spamKeywords = [
  'free', 'win', 'winner', 'won', 'prize', 'urgent', 'action required', 
  'offer', 'limited time', 'credit', 'cash', 'deal', 'discount',
  'claim', 'congrat', 'click', 'link', 'offer', 'money', 'cash',
  'gift', 'payment', 'investment', 'lottery', 'bitcoin', 'crypto',
  '$', '€', '£', 'urgent', 'verify', 'account', 'password',
  'bank', 'deposit', 'withdrawal', 'opportunity'
];

const spamPatterns = [
  /\d+%\s+off/i,
  /free\s+[a-z\s]+/i,
  /click\s+[a-z\s]+\s+link/i,
  /limited\s+time/i,
  /\$\d+/i,
  /€\d+/i,
  /£\d+/i,
  /\d+%/i,
  /act\s+now/i,
  /call\s+now/i,
  /congratulations/i,
  /you\s+have\s+won/i,
  /verify\s+your/i
];

export interface ClassificationResult {
  isSpam: boolean;
  confidence: number;
  keywords?: string[];
}

// TF.js based classifier
export const classifyMessage = (message: string): ClassificationResult => {
  if (!message) {
    return { isSpam: false, confidence: 0 };
  }
  
  const lowerMessage = message.toLowerCase();
  let spamScore = 0;
  const detectedKeywords: string[] = [];
  
  // Check for keywords
  spamKeywords.forEach(keyword => {
    if (lowerMessage.includes(keyword.toLowerCase())) {
      spamScore += 1;
      detectedKeywords.push(keyword);
    }
  });
  
  // Check for patterns
  spamPatterns.forEach(pattern => {
    if (pattern.test(lowerMessage)) {
      spamScore += 2;
      const match = lowerMessage.match(pattern);
      if (match && match[0]) {
        detectedKeywords.push(match[0]);
      }
    }
  });
  
  // Calculate confidence using sigmoid function
  const normalizedScore = tf.scalar(spamScore / 10).sigmoid().dataSync()[0];
  
  // Boost confidence for short messages with high spam score
  let confidence = normalizedScore;
  if (message.length < 50 && spamScore > 3) {
    confidence = Math.min(normalizedScore * 1.5, 1);
  }
  
  // Some predefined examples for demonstration
  if (lowerMessage.includes('congrats! you won a $1000 voucher')) {
    return { isSpam: true, confidence: 0.97, keywords: ['congrats', 'won', '$1000', 'voucher'] };
  }
  
  if (lowerMessage.includes('your parcel is waiting for delivery')) {
    return { isSpam: true, confidence: 0.89, keywords: ['parcel', 'waiting', 'delivery'] };
  }
  
  if (lowerMessage.includes('hey, are we still meeting tomorrow?')) {
    return { isSpam: false, confidence: 0.95 };
  }
  
  if (lowerMessage.includes('can you pick up some milk on your way home?')) {
    return { isSpam: false, confidence: 0.98 };
  }
  
  return {
    isSpam: confidence > 0.5,
    confidence: confidence > 0.5 ? confidence * 100 : (1 - confidence) * 100,
    keywords: detectedKeywords.length > 0 ? [...new Set(detectedKeywords)] : undefined
  };
};