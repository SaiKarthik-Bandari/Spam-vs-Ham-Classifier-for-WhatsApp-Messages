import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Demo from './components/Demo';
import HowItWorks from './components/HowItWorks';
import TrustBuilders from './components/TrustBuilders';
import Footer from './components/Footer';
import { MessageClassifierProvider } from './context/MessageClassifierContext';

function App() {
  return (
    <MessageClassifierProvider>
      <div className="min-h-screen bg-gray-50">
        <Header />
        <Hero />
        <Demo />
        <HowItWorks />
        <TrustBuilders />
        <Footer />
      </div>
    </MessageClassifierProvider>
  );
}

export default App;