/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        'poppins': ['Poppins', 'sans-serif'],
        'open-sans': ['Open Sans', 'sans-serif'],
      },
      colors: {
        'ham': '#4CAF50',
        'spam': '#F44336',
      },
      animation: {
        'bounce-slow': 'bounce 3s infinite',
      },
    },
  },
  plugins: [
    function({ addUtilities }) {
      const newUtilities = {
        '.aspect-w-16': {
          aspectRatio: '16 / 9',
        },
        '.aspect-h-9': {
          aspectRatio: '16 / 9',
        },
      };
      addUtilities(newUtilities);
    },
  ],
};