from flask import Flask, render_template, request, jsonify
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
import os
import json

app = Flask(__name__)

# Load and prepare the dataset
def load_data():
    # Sample dataset for demonstration
    data = {
        'message': [
            "URGENT! You have won a 1000 dollar prize",
            "Congratulations! Claim your free gift now",
            "Hey, are we still meeting tomorrow?",
            "Can you pick up some milk on your way home?",
            "SPECIAL OFFER! 90% off luxury watches",
            "Your account needs verification urgently",
            "Don't forget the meeting at 3pm",
            "What time should I come over?",
            "You've won an iPhone! Click here",
            "Free prize waiting for you!"
        ],
        'label': [1, 1, 0, 0, 1, 1, 0, 0, 1, 1]  # 1 for spam, 0 for ham
    }
    return pd.DataFrame(data)

# Initialize and train the model
def initialize_model():
    df = load_data()
    vectorizer = TfidfVectorizer(max_features=1000)
    X = vectorizer.fit_transform(df['message'])
    y = df['label']
    
    model = MultinomialNB()
    model.fit(X, y)
    
    return vectorizer, model

vectorizer, model = initialize_model()

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/classify', methods=['POST'])
def classify():
    data = request.get_json()
    message = data.get('message', '')
    
    # Transform the message
    message_vectorized = vectorizer.transform([message])
    
    # Get prediction and probability
    prediction = model.predict(message_vectorized)[0]
    proba = model.predict_proba(message_vectorized)[0]
    confidence = proba[1] if prediction == 1 else proba[0]
    
    # Get feature importance
    feature_importance = {}
    if prediction == 1:  # If spam
        feature_names = vectorizer.get_feature_names_out()
        message_vector = message_vectorized.toarray()[0]
        for idx, value in enumerate(message_vector):
            if value > 0:
                feature_importance[feature_names[idx]] = float(value)
    
    # Sort and get top features
    keywords = sorted(feature_importance.items(), key=lambda x: x[1], reverse=True)[:5]
    keywords = [k[0] for k in keywords]
    
    return jsonify({
        'isSpam': bool(prediction),
        'confidence': float(confidence * 100),
        'keywords': keywords if prediction == 1 else []
    })

if __name__ == '__main__':
    app.run(debug=True)